// Configuração pública: não colocar senhas SMTP ou chaves privadas neste arquivo.
export const emailDeContato = 'pedronicolaulacerda@gmail.com'
export const endpointDeContato = `https://formsubmit.co/ajax/${emailDeContato}`
export const formularioDeContato = `https://formsubmit.co/${emailDeContato}`
export const tempoLimiteDeEnvio = 20_000
