export const logotiposDeClientes = '/images/logos-clientes.png'
