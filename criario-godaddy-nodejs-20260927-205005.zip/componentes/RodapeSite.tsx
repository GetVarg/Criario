import { LogotipoCriario } from './LogotipoCriario'
import styles from './RodapeSite.module.css'
import { itensDeNavegacao } from '../dados/navegacao'
import type { Textos } from '../locales'
import { LinkDeContato } from '../funcionalidades/contato/LinkDeContato'

export function RodapeSite({ textos }: { textos: Textos }) {
  return (
    <footer className={styles.rodape}>
      <div className={styles.marca}><LogotipoCriario texto={textos.marca} /></div>
      <div className={styles.links}>
        {itensDeNavegacao.map(({ id, destino }) => destino === 'fale-conosco'
          ? <LinkDeContato key={id}>→ &nbsp; {textos.navegacao[id]}</LinkDeContato>
          : <a key={id} href={'#' + destino}>→ &nbsp; {textos.navegacao[id]}</a>)}
      </div>
      <div className={styles.especialistas}>
        <span>{textos.rodape.especialistas}</span>
        <LinkDeContato aria-label={textos.rodape.especialistasRotulo}>◉</LinkDeContato>
      </div>
      <div className={styles.copyright}>{textos.rodape.copyright}</div>
    </footer>
  )
}
